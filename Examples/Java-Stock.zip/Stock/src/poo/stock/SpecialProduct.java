package poo.stock;

public class SpecialProduct extends Product {

	protected double pricePerDay;

	public SpecialProduct(double price, double pricePerDay) {
		super(price);
		this.pricePerDay = pricePerDay;
	}

	public double getStockPrice(int days) {
		return super.getStockPrice(days) + days * this.pricePerDay;
	}

}
