package poo.stock;

public class PerishableProduct extends SpecialProduct {

	protected double rottenPercentage;

	public PerishableProduct(double price, double pricePerDay,
			double rottenPercentage) {
		super(price, pricePerDay);
		this.rottenPercentage = rottenPercentage;
	}

	@Override
	public double getStockPrice(int days) {
		return super.getStockPrice(days) - days * this.rottenPercentage * this.price;
	}
}
