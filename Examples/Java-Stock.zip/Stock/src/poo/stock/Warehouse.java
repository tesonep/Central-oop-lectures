package poo.stock;

import java.util.ArrayList;
import java.util.List;

public class Warehouse {

	protected List<Pallet> pallets = new ArrayList<>();
	
	public void addPallet(Pallet p) {
		pallets.add(p);
	}

	public double getStockPrice() {
		double total = 0.0;
		
		for (Pallet pallet : pallets) {
			total += pallet.getStockPrice();
		}
		
		return total;
	}

	public void updateNumberOfDays() {
		pallets.forEach((Pallet p) -> p.updateNumberOfDays());
	}
}
