package poo.stock;

import java.util.ArrayList;
import java.util.List;

public class Pallet {

	protected List<Item> items = new ArrayList<>();
	
	public void addItem(Item product) {
		items.add(product);
	}

	public double getStockPrice() {
		double total = 0.0;
		
		for (Item item : items) {
			total += item.getStockPrice();
		}
		
		return total;
	
	}
	
	public void updateNumberOfDays() {
		this.items.forEach((Item i) -> i.updateNumberOfDays());
	}
}
