package poo.stock;

public class ItemWithDays extends Item {

	protected int numberOfDays;

	public ItemWithDays(int quantity, SpecialProduct product, int days) {
		super(quantity, product);
		this.numberOfDays = days;
	}

	public double getStockPrice() {
		return this.quantity * this.product.getStockPrice(numberOfDays);
	}

	public Integer getNumberOfDays() {
		return numberOfDays;
	}

	public void updateNumberOfDays() {
		numberOfDays += 1;
	}

}
