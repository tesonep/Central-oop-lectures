package poo.stock;

public class Item {
	protected int quantity;
	protected Product product;
	
	public Item(int quantity, Product product) {
		this.quantity = quantity;
		this.product = product;
	}
	
	public double getStockPrice() {
		return this.quantity * this.product.getStockPrice();
	}

	public void updateNumberOfDays() {
		
	}
}
