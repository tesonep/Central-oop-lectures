package poo.stock;

public class Product {

	protected double price;

	public Product(double price) {
		this.price = price;
	}

	public double getStockPrice() {
		return this.price;
	}

	public void setPrice(double newPrice) {
		this.price = newPrice;
	}

	public double getStockPrice(int numberOfDays) {
		return this.getStockPrice();
	}

}
