package poo.stock.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import poo.stock.Item;
import poo.stock.ItemWithDays;
import poo.stock.Pallet;
import poo.stock.PerishableProduct;
import poo.stock.Product;
import poo.stock.SpecialProduct;
import poo.stock.Warehouse;

class WarehouseTest {

	@Test
	void testWarehousePriceIsTheSumOfAllPallets() {
		Warehouse w = new Warehouse();

		Pallet p1 = new Pallet();
		p1.addItem(new Item(10, new Product(7.0)));
		p1.addItem(new Item(3, new Product(5.0)));
		p1.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0),5));

		Pallet p2 = new Pallet();
		p2.addItem(new Item(10,new Product(7.0))); //Normal Product
		p2.addItem(new ItemWithDays(3, new PerishableProduct(5.0, 0.5, 0.05), 2)); //Perishable Product
		p2.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0),5)); //Special Product 

		w.addPallet(p1);
		w.addPallet(p2);
		
		assertEquals(p1.getStockPrice() + p2.getStockPrice(), w.getStockPrice());		
	}
	
	@Test
	void testUpdatingDaysChangeNumberOfDays() {
		Warehouse w = new Warehouse();

		Pallet p1 = new Pallet();
		p1.addItem(new Item(10, new Product(7.0)));
		p1.addItem(new Item(3, new Product(5.0)));
		p1.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0),5));

		Pallet p2 = new Pallet();
		p2.addItem(new Item(10,new Product(7.0))); //Normal Product
		ItemWithDays item = new ItemWithDays(3, new PerishableProduct(5.0, 0.5, 0.05), 2);
		p2.addItem(item); //Perishable Product
		p2.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0),5)); //Special Product 

		w.addPallet(p1);
		w.addPallet(p2);
		
	
		assertEquals(2, item.getNumberOfDays());

		w.updateNumberOfDays();
		
		assertEquals(3, item.getNumberOfDays());		
	}
}
