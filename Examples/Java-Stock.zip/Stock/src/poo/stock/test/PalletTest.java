package poo.stock.test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import poo.stock.Item;
import poo.stock.ItemWithDays;
import poo.stock.Pallet;
import poo.stock.PerishableProduct;
import poo.stock.Product;
import poo.stock.SpecialProduct;

class PalletTest {

	@Test
	void testThreeNormalProducts() {
		Pallet p = new Pallet();
		p.addItem(new Item(10, new Product(7.0)));
		p.addItem(new Item(3, new Product(5.0)));
		p.addItem(new Item(7, new Product(5.0)));

		assertEquals(70 + 15 + 35, p.getStockPrice());
	}

	@Test
	void testTwoNormalProductsAndOneSpecial() {
		Pallet p = new Pallet();
		p.addItem(new Item(10, new Product(7.0)));
		p.addItem(new Item(3, new Product(5.0)));
		p.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0), 5));

		assertEquals(70 + 15 + 70, p.getStockPrice());
	}

	@Test
	void testOneProductOfEachType() {
		Pallet p = new Pallet();
		p.addItem(new Item(10,new Product(7.0))); //Normal Product
		p.addItem(new ItemWithDays(3, new PerishableProduct(5.0, 0.5, 0.05), 2)); //Perishable Product
		p.addItem(new ItemWithDays(7, new SpecialProduct(5.0, 1.0), 5)); //Special Product 
		
		assertEquals(70 + 16.5 + 70, p.getStockPrice());
	}
	
	void testSharingProduct() {
		Pallet p = new Pallet();
		Product product = new Product(7.0);
		
		p.addItem(new Item(10, product)); //Normal Product
		
		Pallet p2 = new Pallet();
		p2.addItem(new Item(3, product)); //Normal Product
		
		assertEquals( 70 , p.getStockPrice());
		assertEquals( 21 , p2.getStockPrice());

		product.setPrice(5.0);

		assertEquals( 50 , p.getStockPrice());
		assertEquals( 15 , p2.getStockPrice());

	}

}
