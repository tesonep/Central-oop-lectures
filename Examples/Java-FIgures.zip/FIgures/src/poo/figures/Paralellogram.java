package poo.figures;

public abstract class Paralellogram implements Figure {

	@Override
	public int color() {
		// TODO Auto-generated method stub
		return 0;
	}
}
