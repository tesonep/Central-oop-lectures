package poo.figures;

public interface Figure {
	
	public double area();
	public int color();
}
