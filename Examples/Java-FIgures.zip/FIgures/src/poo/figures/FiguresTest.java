package poo.figures;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

class FiguresTest {

	@Test
	void test() {
		Figure x;
		
		x = new Circle(1);
		assertEquals(Math.PI, x.area());

		x = new Square(1);
		assertEquals(1, x.area());

		x = new Rectangle(1, 1);
		assertEquals(1, x.area());

	}

	@Test
	void testForeach() {
		List<Figure> l = new ArrayList<Figure>();
		l.add(new Circle(1));
		l.add(new Square(1));

		double sum = 0.0;

		for (Figure figure : l) {
			sum += figure.area();
		}

		assertEquals(Math.PI + 1.0, sum);
		
		Iterator<Figure> iterator = l.iterator();

		sum = 0;
		while(iterator.hasNext()) {
			sum += iterator.next().area();
		}

		assertEquals(Math.PI + 1.0, sum);

		sum = 0;
		for(int idx = 0; idx < l.size(); idx++) {
			sum += l.get(idx).area();
		}
		
		
		assertEquals(Math.PI + 1.0, sum);
	}

	@Test
	void testStreamForeach() {
		List<Figure> l = new ArrayList<Figure>();
		
		l.add(new Circle(1));
		l.add(new Square(1));
		
		double sum = 0.0;

		sum = l.stream().reduce(0.0, 
				(accum,f)-> accum + f.area(), 
				(accum,anotherAccum)-> accum );
				
		assertEquals((Math.PI + 1.0), sum, 0.01);
	}	
	
	@Test
	void testParallelStreamForeach() {
		List<Figure> l = new ArrayList<Figure>();
		
		int times = 1000000;
		
		for(int i =0; i < times; i++) {
			l.add(new Circle(1));
			l.add(new Square(1));
		}
		
		double sum = 0.0;

		sum = l.stream().parallel().reduce(0.0, 
				(accum,f)-> accum + f.area(), 
				(accum,anotherAccum)-> accum + anotherAccum);
				
		assertEquals((Math.PI + 1.0)*times, sum, 0.01);
	}

}








