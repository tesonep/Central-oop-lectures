package poo.figures;

public class Square extends Paralellogram {

	double length;
	
	public double area() {
		return Math.pow(length, 2);
	}
	
	public double perimeter() {
		return length * 4;
	}
	
	public Square(double l) {
		this.length = l;
	}

}
