package poo.figures;

public class Rectangle extends Paralellogram {

	double height;
	double width;
	
	public double area() {
		return height * width;
	}
	
	public double perimeter() {
		return height * 2 + width * 2;
	}
	
	public Rectangle(double h, double w) {
		this.height = h;
		this.width = w;
	}
	
}
