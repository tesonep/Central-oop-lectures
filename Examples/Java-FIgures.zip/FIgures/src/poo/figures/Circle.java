package poo.figures;

public class Circle implements Figure{
	protected double radius;
	
	public double area() {
		return Math.PI * (Math.pow(radius,2));
	}
	
	public double perimeter() {
		return Math.PI * 2 * radius;
	}
	
	public Circle(double radius) {
		this.radius = radius;
	}

	@Override
	public int color() {
		// TODO Auto-generated method stub
		return 0;
	}
}
